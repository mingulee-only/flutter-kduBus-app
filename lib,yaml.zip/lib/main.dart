import 'package:flutter/material.dart';
import 'package:flutter_loginemailex1/flutter_firebase/user_provider.dart';
//import 'google_signin/google_signin_demo.dart';
import 'package:provider/provider.dart';
import 'flutter_firebase/firebase_provider.dart';
import 'flutter_firebase/mail/auth_page.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
//https://github.com/FirebaseExtended/flutterfire/issues/2599
//web_core

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<FirebaseProvider>(
            builder: (_) => FirebaseProvider()),
        ChangeNotifierProvider(
            builder: (_) => UserProvider()),
      ],
      child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: "Flutter Firebase",
          home: HomePage(),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AuthPage();
  }
}