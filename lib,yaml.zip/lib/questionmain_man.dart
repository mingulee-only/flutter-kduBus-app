import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';

import 'flutter_firebase/firebase_provider.dart';
//https://github.com/FirebaseExtended/flutterfire/issues/2599
//오류:Plugin project :firebase_core_web not found. Please update settings.gradle.



class QtoMan {
  bool isDone;
  String title;
  String userId;
  String userRoll;

  QtoMan(this.title, this.userId, {this.isDone = false});
  QtoMan.all(this.title, this.userId, this.userRoll ,{this.isDone = false});
}

_ToStuListPageState pageState;

class ToStuListPage extends StatefulWidget {
  @override
  _ToStuListPageState createState() {
    pageState = _ToStuListPageState();
    return pageState;
  }
}

class _ToStuListPageState extends State<ToStuListPage> {
  FirebaseProvider fp;

  var _questController = TextEditingController();

  void dispose(){
    _questController.dispose();
    super.dispose();
  }

  Widget _buildItemWidget(DocumentSnapshot doc, String userId){
    final toMan = QtoMan(doc['title'], userId, isDone: doc['isDone'],);
    return ListTile(
      onTap:() => _toggleTodo(doc),
      title: Text(
        toMan.title,
        style: toMan.isDone? TextStyle(
          decoration: TextDecoration.lineThrough,
          fontStyle: FontStyle.italic,
        ) : null, //todo 아직 안 끝나면 적용 X
      ),
      trailing: IconButton(
        icon: Icon(doc['userId'] == userId? Icons.delete_forever : null),
        onPressed: () => _deleteTodo(doc),    //todo 쓰레기통  클릭시 삭제되도록 수정
      ),
    );
  }

  Widget _buildanswerWidget(DocumentSnapshot doc, String userId, String roll){
    final toMan = QtoMan.all(doc['title'], userId, roll, isDone: doc['isDone']);
    return ListTile(
      onTap:() => _toggleTodo(doc),
      title: Text(
        toMan.title,
        style:  TextStyle(
          decoration: doc['isDone']? TextDecoration.lineThrough : null,
          color: doc['userId'] == userId? Colors.blue : null,
        ), //todo 아직 안 끝나면 적용 X
      ),
      trailing: IconButton(
        icon: Icon(doc['userId'] == userId? Icons.delete_forever : null),
        onPressed: () => _deleteTodo(doc),    //todo 쓰레기통  클릭시 삭제되도록 수정
      ),
    );
  }

  void _addTodo(QtoMan toMan) {
    Firestore.instance
        .collection('QtoMan')
        .add({'title': toMan.title, 'userId' : toMan.userId,
      'userRoll' : toMan.userRoll, 'isDone': toMan.isDone});
    _questController.text = '';
  }


  void _deleteTodo(DocumentSnapshot doc) {
    if(doc['userId'] == fp.getUser().uid){
      Firestore.instance.collection('QtoMan').document(doc.documentID).delete();
    }

  }

  void _toggleTodo(DocumentSnapshot doc){  //isdone으로 만들어줌 (이거를 tap에다가)
    Firestore.instance.collection('QtoMan').document(doc.documentID).updateData({
      'isDone': !doc['isDone'],
    });
  }
  @override
  Widget build(BuildContext context) {
    fp = Provider.of<FirebaseProvider>(context);
    return Scaffold(
        appBar: AppBar(
          title: Container(
                child: Row(
                  children: [
                    Expanded(child: Text('건의 사항')),
                  ],
                ),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: <Widget>[

              StreamBuilder<QuerySnapshot>(
                  stream: Firestore.instance.collection('QtoMan').snapshots(),
                  builder: (context, snapshot) {
                    if(!snapshot.hasData){
                      return CircularProgressIndicator();
                    }
                    final documents = snapshot.data.documents;
                    return Expanded(
                      child: ListView(
                        children: documents
                            .map((doc) => _buildanswerWidget(doc, fp.getUser().uid, doc['userRoll'])).toList(),
                      ),
                    );
                  }
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: TextField(
                        controller: _questController,
                      ),
                    ),
                    RaisedButton(
                      child: Text('추가'),
                      onPressed: () => _addTodo(QtoMan(_questController.text, fp.getUser().uid)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
    );
  }
}
