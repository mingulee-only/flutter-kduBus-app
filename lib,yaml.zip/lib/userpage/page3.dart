import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_loginemailex1/flutter_firebase/firebase_provider.dart';
import 'package:flutter_loginemailex1/flutter_firebase/models/user_model.dart';
import 'package:flutter_loginemailex1/flutter_firebase/user_provider.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';



class Page3 extends StatefulWidget {
  @override
  _Page3State createState() => _Page3State();
}

class _Page3State extends State<Page3> {

  UserProvider up;

  SharedPreferences prefs;
  FirebaseProvider fp;
  String id = '';
  String name = '';
  String number = '';
  String roll = '';

  void settingtestUser() async {
    final QuerySnapshot result = await Firestore.instance
        .collection('User')
        .where('userId', isEqualTo: fp.getUser().uid)
        .getDocuments();
    final List<DocumentSnapshot> documents = result.documents;
    id = documents[0].data['id'] ?? '';
    name = documents[0].data['name'] ?? '';
    number = documents[0].data['number'] ?? '';
    roll = documents[0].data['roll'] ?? '';
  }


  @override
  Widget build(BuildContext context) {
    fp = Provider.of<FirebaseProvider>(context);
    setState(() {
      settingtestUser();
    });
    return Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              '학생의 학번으로 생성된 QR코드 입니다.',
            ),
            Text(
              '셔틀버스 이용 시, 관리자에게 QR코드를 제시해 주세요',
            ),
            Container(
                  child: QrImage(
                    data: number,
                    size: 200.0,
                  ),
                ),
            RaisedButton(
              onPressed: () {
                setState(() {
                  settingtestUser();
                });
            },
              child: Text('새로고침', style: TextStyle(fontSize: 20)),),
          ],
        ),
    );
  }
}
