import 'package:flutter/material.dart';
import 'package:flutter_loginemailex1/userpage/BustoKDU.dart';
import 'package:flutter_loginemailex1/userpage/BustoStation.dart';

class Page2 extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: ListView(
        scrollDirection: Axis.vertical,
        children: <Widget>[
          ListTile(
            leading: Icon(Icons.directions_bus),
            title: Text('등교'),
            trailing: Icon(Icons.navigate_next),
            onTap: (){
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => Bustokdu()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.directions_bus),
            title: Text('하교'),
            trailing: Icon(Icons.navigate_next),
            onTap: (){
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => Bustostation()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.directions_bus),
            title: Text('701번 시간표(양주역)'),
            trailing: Icon(Icons.navigate_next),
            onTap: (){
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Page12()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.directions_bus),
            title: Text('73-3번 시간표(덕계역)'),
            trailing: Icon(Icons.navigate_next),
            onTap: (){
              Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Page22()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class Page12 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('701번 시간표(양주역)'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Image.asset('assets/images/701.jpg'),
        ],
      ),
    );
  }
}

class Page22 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('73-3번 시간표(덕계역)'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Image.asset('assets/images/73-3.jpg'),
        ],
      ),
    );
  }
}