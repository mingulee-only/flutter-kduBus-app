import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_loginemailex1/managerpage/models/bus_model.dart';

List<String> buslistam = ['nine', 'ten', 'eleven'];
List<String> buslistpm = ['five', 'six', 'seven'];
List<String> titlelist = ['_one', '_two', '_thr', '_four'];

class Bustostation extends StatefulWidget {
  @override
  _BustostationState createState() => _BustostationState();
}



class _BustostationState extends State<Bustostation> {
  String state = '대기';

  int _count = 0;
  int max = 40;



/*이걸로 정리해서 화면 바뀔 수 있게 합치고 싶음*/
  Widget _buildState(DocumentSnapshot doc, String col){
    return null;
  }

  Widget _buildAMState(String col){
    String textTitle;
    if(col == buslistam[0]){
      textTitle = " 경동대, 9시 20분 도착";
    } else if(col == buslistam[1]){
      textTitle = " 경동대, 10시 20분 도착";
    } else if(col == buslistam[2]){
      textTitle = " 경동대, 11시 20분 도착";
    } else {

    }
    return Column(
        children: <Widget>[
          Container(
            margin: const EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 10),
            child: Row(
                children: <Widget>[
                  Icon(Icons.directions_bus,
                    color: Colors.blueAccent,),
                  Text(textTitle,
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.black,
                        fontWeight: FontWeight.bold
                    ),
                  ),
                ]
            ),
          ),
          StreamBuilder<QuerySnapshot>(
              stream: Firestore.instance.collection('Bus').document('busAM')
                  .collection(col).orderBy('title', descending: false).snapshots(),
              builder: (context, snapshot) {
                if(!snapshot.hasData){
                  return CircularProgressIndicator();
                }
                final documents = snapshot.data.documents;
                return Expanded(
                  child: ListView(
                    children: documents
                        .map((doc) => _buildBusstateWidget(doc)).toList(),
                  ),
                );
              }
          ),

        ]


    );
  }


  Widget _buildPMState(String col){
    String textTitle;
    if(col == buslistpm[0]){
      textTitle = " 도봉산, 17시 도착";
    } else if(col == buslistpm[1]){
      textTitle = " 도봉산, 18시 도착";
    } else if(col == buslistpm[2]){
      textTitle = " 도봉산, 19시 도착";
    } else {

    }
    return Column(
        children: <Widget>[
          Container(
            margin: const EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 10),
            child: Row(
                children: <Widget>[
                  Icon(Icons.directions_bus,
                    color: Colors.blueAccent,),
                  Text(textTitle,
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.black,
                        fontWeight: FontWeight.bold
                    ),
                  ),
                ]
            ),
          ),
          StreamBuilder<QuerySnapshot>(
              stream: Firestore.instance.collection('Bus').document('busPM')
                  .collection(col).orderBy('title', descending: false).snapshots(),
              builder: (context, snapshot) {
                if(!snapshot.hasData){
                  return CircularProgressIndicator();
                }
                final documents = snapshot.data.documents;
                return Expanded(
                  child: ListView(
                    children: documents
                        .map((doc) => _buildBusstateWidget(doc)).toList(),
                  ),
                );
              }
          ),

        ]


    );
  }

  Widget _buildBusstateWidget(DocumentSnapshot doc) {
    final bus = Bus.all(doc['title'], doc['count'], doc['state']);

    return ListTile(
      onTap: () {

      } /*_toggleTodo(bus)*/,
      title: Row(
        children: <Widget>[
          Text(bus.title,
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),),
          SizedBox(width: 60,),
          Text('탑승 인원 : ${bus.count}/40'),
          SizedBox(width: 60),

          SizedBox(
              child: Center(
                child: Text(bus.state,
                  style: TextStyle(color: doc['state'] == "도착"? Colors.redAccent : Colors.blueAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )),

        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          '운행 버스',
          style: TextStyle(color: Colors.black),
        ), //맨 위 상단 페이지 이름, 색상 변경
        centerTitle: true,
      ),
      body: PageView(
        children: <Widget>[
          Container(
            child:Column(
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 10),
                    child: Row(
                        children: <Widget>[
                          Icon(Icons.directions_bus,
                            color: Colors.blueAccent,),
                          Text(" 도봉산, 17시 도착",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.black,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ]
                    ),
                  ),
                  StreamBuilder<QuerySnapshot>(
                      stream: Firestore.instance.collection('Bus').document('busPM')
                          .collection('five').orderBy('title', descending: false).snapshots(),
                      builder: (context, snapshot) {
                        if(!snapshot.hasData){
                          return CircularProgressIndicator();
                        }
                        final documents = snapshot.data.documents;
                        return Expanded(
                          child: ListView(
                            children: documents
                                .map((doc) => _buildBusstateWidget(doc)).toList(),
                          ),
                        );
                      }
                  ),

                  Container(
                    margin: const EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 10),
                    child: Row(
                        children: <Widget>[
                          Icon(Icons.directions_bus,
                            color: Colors.blueAccent,),
                          Text(" 도봉산, 18시 도착",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.black,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ]
                    ),
                  ),
                  StreamBuilder<QuerySnapshot>(
                      stream: Firestore.instance.collection('Bus').document('busPM')
                          .collection('six').orderBy('title', descending: false).snapshots(),
                      builder: (context, snapshot) {
                        if(!snapshot.hasData){
                          return CircularProgressIndicator();
                        }
                        final documents = snapshot.data.documents;
                        return Expanded(
                          child: ListView(
                            children: documents
                                .map((doc) => _buildBusstateWidget(doc)).toList(),
                          ),
                        );
                      }
                  ),

                Container(
                  margin: const EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 10),
                  child: Row(
                      children: <Widget>[
                        Icon(Icons.directions_bus,
                          color: Colors.blueAccent,),
                        Text(" 도봉산, 19시 도착",
                          style: TextStyle(
                              fontSize: 18,
                              color: Colors.black,
                              fontWeight: FontWeight.bold
                          ),
                        ),
                      ]
                  ),
                ),
                StreamBuilder<QuerySnapshot>(
                    stream: Firestore.instance.collection('Bus').document('busPM')
                        .collection('seven').orderBy('title', descending: false).snapshots(),
                    builder: (context, snapshot) {
                      if(!snapshot.hasData){
                        return CircularProgressIndicator();
                      }
                      final documents = snapshot.data.documents;
                      return Expanded(
                        child: ListView(
                          children: documents
                              .map((doc) => _buildBusstateWidget(doc)).toList(),
                        ),
                      );
                    }
                ),

              ],

            ),
          ),
        ],
      ),



    );
  }
}
