import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'page1.dart';
import 'page2.dart';
import 'page3.dart';
import 'page4.dart';
import 'page5.dart';


class MainUser extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'kduApp',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
      ),
      home: UserHome(),
    );
  }
}


class UserHome extends StatefulWidget {
  @override
  _UserHomeState createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {

  SharedPreferences prefs;
  String id = '';
  String name = '';
  String number = '';
  String roll = '';

  void settingUser() async {
    prefs = await SharedPreferences.getInstance();
    id = prefs.getString('id') ?? '';
    name = prefs.getString('name') ?? '';
    number = prefs.getString('number') ?? '';
    roll = prefs.getString('roll') ?? '';
  }



  var _index = 0;
  var _pages = [
    Page2(),
    Page3(),
    Page5(),
  ];

  @override
  Widget build(BuildContext context) {
    settingUser();
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.white,
          title: Text(
            '경동대학교 통학 어플',
            style: TextStyle(color: Colors.black),
          ), //맨 위 상단 페이지 이름, 색상 변경
          centerTitle: true,
          actions: <Widget>[
            IconButton(
              icon: Icon(
                Icons.dehaze,
                color: Colors.black,
              ),
              onPressed: () {},
            )
          ]),
      body: _pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blueAccent,
        unselectedItemColor: Colors.white60,
        fixedColor: Colors.white,
        onTap: (index) {
          setState(() {
            _index = index;
            settingUser();
          });
        },
        currentIndex: _index,
        items: <BottomNavigationBarItem>[
          /*
          BottomNavigationBarItem(
            title: Text('홈페이지'),
            icon: Image.asset('icon/home_white_36_1x.png',
            width: 30, height: 30, fit: BoxFit.fill, color: Colors.white38,),
            activeIcon: Image.asset('icon/home_white_36_1x.png',
            width: 30, height: 30, fit: BoxFit.fill,),
             ),

           */
          BottomNavigationBarItem(
            title: Text('버스시간표'),
            icon: Image.asset('icon/bus_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill, color: Colors.white38,),
            activeIcon: Image.asset('icon/bus_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill,),
          ),
          BottomNavigationBarItem(
            title: Text('QR코드'),
            icon: Image.asset('icon/qrcode2_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill, color: Colors.white38,),
            activeIcon: Image.asset('icon/qrcode2_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill,),
          ),
          /*
          BottomNavigationBarItem(
            title: Text('채팅방'),
            icon: Image.asset('icon/dotchat_white_36_1x.png',
            width: 30, hei,ght: 30, fit: BoxFit.fill, color: Colors.white38,),
            activeIcon: Image.asset('icon/dotchat_white_36_1x.png',
            width: 30, height: 30, fit: BoxFit.fill,),
          ),*/
          BottomNavigationBarItem(
            title: Text('설정'),
            icon: Image.asset('icon/setting_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill, color: Colors.white38,),
            activeIcon: Image.asset('icon/setting_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill,),

          )
        ],
      ),
    );
  }
}
