import 'package:flutter/material.dart';
import 'page3.dart';
import 'package:qr_flutter/qr_flutter.dart';

class Page1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        _buildTop(),
        _buildMiddle(),
        _buildBottom(),
      ],
    );
  }

  Widget _buildTop() {
    return
      ListTile(
        leading: Image.asset('icon/bus_white_36_1x.png',
        width: 30, height: 30, fit: BoxFit.fill,
            color: Colors.blueAccent,),
        title: Text('지금 운행 중인 버스'),
        subtitle: Text('9시 반 1호차    3/40    대기'),
      );

  }

  Widget _buildMiddle() {
    return
            Center(
              // Center is a layout widget. It takes a single child and positions it
              // in the middle of the parent.
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'OOO의 QR코드입니다',
                    style: TextStyle(fontSize: 20),
                  ),
                  QrImage(
                    data: "1824025",
                    size: 200.0,
                  )
                ],
              ),
            );

  }

  Widget _buildBottom() {
    return Text('Bottom');
  }
}
