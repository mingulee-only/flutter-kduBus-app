import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:logger/logger.dart';
import 'firebase_provider.dart';

Logger logger = Logger();



class UserProvider with ChangeNotifier {


  FirebaseProvider fp;
  String id = '';
  String name = '';
  String number = '';
  String roll = '';

  void settingUser() async {
    final QuerySnapshot result = await Firestore.instance
        .collection('User')
        .where('userId', isEqualTo: fp.getUser().uid)
        .getDocuments();
    final List<DocumentSnapshot> documents = result.documents;

    id = documents[0].data['id'] ?? '';
    name = documents[0].data['name'] ?? '';
    number = documents[0].data['number'] ?? '';
    roll = documents[0].data['roll'] ?? '';
    notifyListeners();
  }

  String getNumber(){
    settingUser();
    return number;
  }


  String getName(){
    settingUser();
    return name;
  }

  String getRoll(){
    settingUser();
    return roll;
  }




}