import 'package:flutter/material.dart';
import '../firebase_provider.dart';
import 'package:provider/provider.dart';



class Manager {
  String userId;
  String name;
  String position;

  Manager(this.userId, this.name, this.position);
}