import 'package:flutter/material.dart';
import '../firebase_provider.dart';
import 'package:provider/provider.dart';


enum Identi { Stu, Man }

class User {
  String userId;
  String number;
  String name;
  String roll;
 User();
  User.all(this.userId, this.number, this.name);
  User.num(this.number);
  User.id(this.userId);
  User.add(this.userId, this.roll);
}