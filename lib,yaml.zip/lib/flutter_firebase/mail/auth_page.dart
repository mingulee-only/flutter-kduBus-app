import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_loginemailex1/flutter_firebase/models/user_model.dart';
import 'package:flutter_loginemailex1/managerpage/manager_main.dart';
import 'package:flutter_loginemailex1/userpage/user_main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../choiceIdenti.dart';
import '../firebase_provider.dart';
import '../signedinUser.dart';
import 'signedin_page.dart';
import 'signin_page.dart';
import 'package:provider/provider.dart';
import '../signedinUser.dart';
import 'package:cloud_firestore/cloud_firestore.dart';



AuthPageState pageState;

class AuthPage extends StatefulWidget {
  @override
  AuthPageState createState() {
    pageState = AuthPageState();
    return pageState;
  }
}


class AuthPageState extends State<AuthPage> {
  FirebaseProvider fp;
  SharedPreferences prefs;
  String page;

  Future<Page> _buildUserInfoSet() async {
    prefs = await SharedPreferences.getInstance();
    FirebaseUser firebaseUser = fp.getUser();
    FirebaseUser currentUser;

    final QuerySnapshot result = await Firestore.instance
        .collection('User')
        .where('userId', isEqualTo: fp.getUser().uid)
        .getDocuments();
    final List<DocumentSnapshot> documents = result.documents;

    if (documents.length == 0) {
      // Update data to server if new user
      page = 'first';
    } else {
      page = 'main';
      if(documents[0].data['roll'] == "관리자"){
        page = 'mainMan';
      } else{
        page = 'mainStu';
      }
    }



  }

  @override
  Widget build(BuildContext context) {
    fp = Provider.of<FirebaseProvider>(context);


    logger.d("user: ${fp.getUser()}");

    if (fp.getUser() != null && fp.getUser().isEmailVerified == true) {
      return ChoiceIdenti();
    } else {
      return SignInPage();
    }

  }
}