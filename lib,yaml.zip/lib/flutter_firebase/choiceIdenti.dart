import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_loginemailex1/userpage/user_main.dart';
import 'firebase_provider.dart';
import 'package:provider/provider.dart';
import 'package:flutter_loginemailex1/managerpage/manager_main.dart';
import 'models/user_model.dart';

enum Identi { Stu, Man }
ChoiceIdentiState pageState;

class ChoiceIdenti extends StatefulWidget {
  @override
  ChoiceIdentiState createState() {
    pageState = ChoiceIdentiState();
    return pageState;
  }
}


String roll = "";

class ChoiceIdentiState extends State<ChoiceIdenti> {
  FirebaseProvider fp;
  Identi _identi = Identi.Stu;

  Future<void> _addUserInfo(User user, Identi identi) async {
    String documentId = fp.getUser().uid;
    final QuerySnapshot result = await Firestore.instance
        .collection('User')
        .where('userId', isEqualTo: fp.getUser().uid)
        .getDocuments();

    final List<DocumentSnapshot> documents = result.documents;
    if(_identi == Identi.Man){
      roll = "관리자";
    } else {
      roll = "학생";
    }

    if(documents.length == 0){

      Firestore.instance
          .collection('User').document(documentId).
      setData({'userId' : documentId, 'roll' : roll});

    } else {
      Firestore.instance
          .collection('User').document(documentId).
      updateData({'userId' : documentId, 'roll' : roll});
    }


  }

  @override
  Widget build(BuildContext context) {
    double deviceWidth = MediaQuery.of(context).size.width;
    double deviceHight = MediaQuery.of(context).size.height;
    fp = Provider.of<FirebaseProvider>(context);

    
    return Scaffold(
      appBar: AppBar(title: Text("신분 확인"),),
      body: Align(
        alignment: Alignment.center,
        child: Container(
          child: Column(
            children: <Widget>[
              SizedBox(
                height: (deviceHight-500)/4,
              ),
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[

                 Card(
                   shape: RoundedRectangleBorder(
                     borderRadius: BorderRadius.circular(16.0),
                   ),
                   elevation: 4.0,
                   child: Container(

                       child: FlatButton(
                           onPressed: () {
                             setState(() {
                               _identi = Identi.Stu;
                             });

                             },
                           child: Image.asset('icon/user.png',width: (deviceWidth/2)-50, height: 400,)),
                     ),
                   ),


                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.0),
                    ),
                    elevation: 4.0,
                    child: Container(

                        child: FlatButton(
                            onPressed: () {
                              setState(() {
                                _identi = Identi.Man;
                              });

                            },
                            child: Image.asset('icon/man.png',width: (deviceWidth/2)-50, height: 400,)),
                      ),
                    ),

                ],
              ),
              SizedBox(
                height: (deviceHight-500)/6,
              ),
              Align(
                alignment: Alignment.bottomRight,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Expanded(
                          child: Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                              _identi == Identi.Stu?
                              '학생이 맞으신가요?' : '관리자가 맞으신가요?'
                          )
                          ),
                      ),
                      SizedBox(width: 20,),
                      RaisedButton(
                            color: Colors.blue,
                          child: Text('다음',
                            style: TextStyle(
                                color: Colors.white, fontWeight: FontWeight.bold
                            ),
                          ),
                          onPressed: (){
                            _addUserInfo(User.id(fp.getUser().uid), _identi);
                            if (_identi == Identi.Stu) {
                              return Navigator.push(context,
                                  MaterialPageRoute(builder: (context) => MainUser()));
                            } else {
                              return Navigator.push(context,
                                  MaterialPageRoute(builder: (context) => MainManager()));
                            }
                          },
                      ),
                    ],
                  ),
                ),
              ),
            ]
          ),
        ),
      ),
    );
  }
}
