import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_loginemailex1/managerpage/manager_main.dart';
import 'firebase_provider.dart';
import 'package:provider/provider.dart';
import 'models/user_model.dart';
import 'mail/auth_page.dart';
import 'mail/signin_page.dart';
import 'mail/signup_page.dart';
import 'package:flutter_loginemailex1/userpage/user_main.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum Identi { Stu, Man }

Identi _identi = Identi.Stu;

EditedInManState pageState;

class EditedInMan extends StatefulWidget {
  @override
  EditedInManState createState() {
    pageState = EditedInManState();
    return pageState;
  }
}

class EditedInManState extends State<EditedInMan> {
  SharedPreferences prefs;
  FirebaseProvider fp;
  bool numbercheck = false;

  TextStyle tsItem = const TextStyle(
      color: Colors.blueGrey, fontSize: 13, fontWeight: FontWeight.bold);
  TextStyle tsContent = const TextStyle(color: Colors.blueGrey, fontSize: 12);

  TextEditingController _numCon = TextEditingController();
  TextEditingController _nameCon = TextEditingController();
  TextEditingController _nickCon = TextEditingController();

  final _formkey = GlobalKey<FormState>();
  final _formfield = GlobalKey<FormState>();
  @override
  void dispose() {
    _numCon.dispose();
    _nameCon.dispose();
    _nickCon.dispose();
    super.dispose();
  }



  Future<Null> _buildUserNumberCheckWidget(String numcon) async { //학번 중복 체크
    final QuerySnapshot result = await Firestore.instance
        .collection('User')
        .where('number', isEqualTo: numcon)
        .getDocuments();
    final List<DocumentSnapshot> documents = result.documents;
    if(documents.length == 0) {
      numbercheck = true;
    } else {
      numbercheck = false;
    }
  }

  Future<Null> _buildUserInfoSet(User user) async { //정보 입력
    prefs = await SharedPreferences.getInstance();
    FirebaseUser firebaseUser = fp.getUser();
    FirebaseUser currentUser;

    final QuerySnapshot result = await Firestore.instance
        .collection('User')
        .where('userId', isEqualTo: fp.getUser().uid)
        .getDocuments();
    final List<DocumentSnapshot> documents = result.documents;

    Firestore.instance
        .collection('User')
        .document(firebaseUser.uid).updateData({
      'userId': firebaseUser.uid,
      'name': _nameCon.text.trim(),
      'number' : _numCon.text.trim(),
    });

    await prefs.setString('id', documents[0].data['userId']);
    await prefs.setString('name', documents[0].data['name']);
    await prefs.setString('number', documents[0].data['number']);
    await prefs.setString('roll', documents[0].data['roll']);

    _numCon.text="";
    _nameCon.text="";
  }


  Widget _buildUserInfoWidget(DocumentSnapshot doc){
    final user = User.num(doc['number']);

    return ListTile(
      onTap: (){},
      title: Text(user.number),
    );

  }


  void _addNum(User user){
    Firestore.instance
    .collection('User').add({'number' : user.number});  //이름 유의할 것
    _numCon.text="";
  }

  void _readUser(DocumentSnapshot doc, FirebaseProvider fp){
    Firestore.instance.collection('User').document(doc.documentID).get().then((doc) {

    });
    Firestore.instance.collection("Bus").document("busAM").collection("nine")
        .document("nine_one").get().then((value) => null);
  }

  void _updateNum(DocumentSnapshot doc){
    Firestore.instance.collection('User').document(doc.documentID).updateData({
      'number' : _numCon, 'name' : _nameCon, //대충 집어 넣음

    });
  }

  void _deleteNum(DocumentSnapshot doc){
    Firestore.instance.collection('User').document(doc.documentID).delete();
  }

  Widget nullCheck(){
    return Container(
        child: Text("칸이 비어있습니다. 항목을 채워 주세요"));
  }


  @override
  Widget build(BuildContext context) {
    fp = Provider.of<FirebaseProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('개인정보 변경'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form(
          key: _formkey,
          child: Column(
            children: <Widget>[
              TextFormField(
                decoration: InputDecoration(
                  hintText: '이름 입력',
                ),
                controller: _nameCon,
                validator:(value) {
                  if (value
                      .trim()
                      .isEmpty) {
                    return "이름을 입력하세요";
                  }
                  return null;
                }
              ),

                  Center(
                    child: RaisedButton(
                      child: Text('확인'),
                      onPressed: () async {
                        setState(() {
                          if(_formkey.currentState.validate()){
                            _buildUserInfoSet(User.all(fp.getUser().uid, _numCon.text.trim(), _nameCon.text.trim()));
                            //_buildUserInfoSet();
                            Navigator.pop(context);

                          }
                        });

                      },
                    ),
                  ),



              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: RaisedButton(
                  color: Colors.indigo[300],
                  child: Text(
                    "취소",
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );

  }
}
