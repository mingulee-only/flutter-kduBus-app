import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'models/bus_model.dart';

var count=0;


class Buslistam extends StatefulWidget {
  @override
  _BuslistamState createState() => _BuslistamState();
}



class _BuslistamState extends State<Buslistam> {
  String state = '대기';
  //대기, 도착, 출발, 운행 중지
  List<String> buslistam = ['nine', 'ten', 'eleven'];
  List<String> titlelist = ['_one', '_two', '_thr', '_four'];
  List<String> statelist = ["대기", "도착", "출발"];

  void _deletedocu(int i, int j){
    Firestore.instance.collection('Bus').document('busAM').
    collection(buslistam[i]).document((buslistam[i]+titlelist[j]).toString())
    .collection('count').document(doc.documentID)
        .updateData({
      'numcount': FieldValue.delete()
    });
    Firestore.instance.collection('Bus').document('busAM').
    collection(buslistam[i]).document((buslistam[i]+titlelist[j]).toString())
        .collection('count').document(doc.documentID).delete();
  }

  void _stateSetting(DocumentSnapshot doc, String col){
    if(doc['state'] == statelist[0]){
      stream:
      Firestore.instance.collection('Bus').document('busAM')
          .collection(col).document(doc.documentID).updateData({
        'state': statelist[1],
      });

    } else if(doc['state'] == statelist[1]) {
      stream:
      Firestore.instance.collection('Bus').document('busAM')
          .collection(col).document(doc.documentID).updateData({
        'state': statelist[2],
      });
    } else {
      stream:
      Firestore.instance.collection('Bus').document('busAM')
          .collection(col).document(doc.documentID).updateData({
        'state': statelist[0],
      });
    }
  }

  Widget _buildBusstateWidget(DocumentSnapshot doc, String col){
    final bus = Bus.all(doc['title'], doc['count'], doc['state']);
    return ListTile(
      onTap: () {
        setState(() {
          _stateSetting(doc, col);
          }
        );
      } /*_toggleTodo(bus)*/,
      title: Text(bus.title),

      subtitle: Row(
        children: <Widget> [
          Expanded(child: Text('${bus.count}/40')),
          Expanded(child:
          Text(bus.state,
            style: TextStyle(color: (bus.state == "도착") ? Colors.redAccent : Colors.blueAccent,
              fontWeight: FontWeight.bold,
            ),
          )),
        ],
      ),
      trailing: RaisedButton(
        child: Text(bus.state == "운행 중단" ? '운행 재개' : '운행 중단'),
        onPressed: (){
          setState(() {
            if(bus.state != "운행 중단"){
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(col).document(doc.documentID).updateData({
                'state': "운행 중단",
              });
            } else {
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(col).document(doc.documentID).updateData({
                'state': statelist[0],
              });
            }


          });
        },
      ),
    );
  }

  DocumentSnapshot doc;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.lightBlue,
          title: Text(
            '운행 버스 상태 변환',
            style: TextStyle(color: Colors.white),
          ), //맨 위 상단 페이지 이름, 색상 변경
          centerTitle: true,
          actions: <Widget>[
            RaisedButton(
              child: Text('초기화',
                style: TextStyle(color: Colors.white,
                    fontWeight: FontWeight.bold),
              ),
              color: Colors.black12,
              onPressed: (){
                setState(() {

                  for(int i = 0 ; i < buslistam.length; i++){
                    for(int j = 0 ; j < titlelist.length ; j++){
                      Firestore.instance.collection('Bus').document('busAM')
                          .collection(buslistam[i]).document((buslistam[i]+titlelist[j]).toString()).updateData({
                        'count' : 0, 'state': statelist[0],
                      });
                    }


                  }
                });

              },
            ),
          ]),
        body: Column(
            children: <Widget>[
              Container(
                margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                child: Row(
                    children: <Widget>[
                      Icon(Icons.directions_bus,
                        color: Colors.blueAccent,),
                      Text(" 경동대, 9시 20분 도착",
                        style: TextStyle(
                            fontSize: 18,
                            color: Colors.black,
                            fontWeight: FontWeight.bold
                        ),
                      ),
                    ]
                ),
              ),
              StreamBuilder<QuerySnapshot>(
                  stream: Firestore.instance.collection('Bus').document('busAM')
                      .collection('nine').orderBy('title', descending: false).snapshots(),
                  builder: (context, snapshot) {
                    if(!snapshot.hasData){
                      return CircularProgressIndicator();
                    }
                    final documents = snapshot.data.documents;
                    return Expanded(
                      child: ListView(
                        children: documents
                            .map((doc) => _buildBusstateWidget(doc, 'nine')).toList(),
                      ),
                    );
                  }
              ),


              Container(
                margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                child: Row(
                    children: <Widget>[
                      Icon(Icons.directions_bus,
                        color: Colors.blueAccent,),
                      Text(" 경동대, 10시 20분 도착",
                        style: TextStyle(
                            fontSize: 18,
                            color: Colors.black,
                            fontWeight: FontWeight.bold
                        ),
                      ),
                    ]
                ),
              ),
              StreamBuilder<QuerySnapshot>(
                  stream: Firestore.instance.collection('Bus').document('busAM')
                      .collection('ten').orderBy('title', descending: false).snapshots(),
                  builder: (context, snapshot) {
                    if(!snapshot.hasData){
                      return CircularProgressIndicator();
                    }
                    final documents = snapshot.data.documents;
                    return Expanded(
                      child: ListView(
                        children: documents
                            .map((doc) => _buildBusstateWidget(doc, 'ten')).toList(),
                      ),
                    );
                  }
              ),
              Container(
                margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                child: Row(
                    children: <Widget>[
                      Icon(Icons.directions_bus,
                        color: Colors.blueAccent,),
                      Text(" 경동대, 11시 20분 도착",
                        style: TextStyle(
                            fontSize: 18,
                            color: Colors.black,
                            fontWeight: FontWeight.bold
                        ),
                      ),
                    ]
                ),
              ),
              StreamBuilder<QuerySnapshot>(
                  stream: Firestore.instance.collection('Bus').document('busAM')
                      .collection('eleven').orderBy('title', descending: false).snapshots(),
                  builder: (context, snapshot) {
                    if(!snapshot.hasData){
                      return CircularProgressIndicator();
                    }
                    final documents = snapshot.data.documents;
                    return Expanded(
                      child: ListView(
                        children: documents
                            .map((doc) => _buildBusstateWidget(doc, 'eleven')).toList(),
                      ),
                    );
                  }
              ),
            ]

        ),





    );
  }
}
