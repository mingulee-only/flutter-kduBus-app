import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'busscanlist_pm.dart';
import 'busscanlist_am.dart';
import 'models/bus_model.dart';

class Page2 extends StatefulWidget {
  @override
  _Page2State createState() => _Page2State();
}

class _Page2State extends State<Page2> {
  final _busto = ['경동대행', '도봉산행'];
  var _selectedValue = '경동대행';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
            children: [
            Align(
            alignment: Alignment.centerLeft,
            child: Container(
              padding: EdgeInsets.all(20.0),
              child: DropdownButton(
                  value: _selectedValue,
                  items: _busto.map(
                        (value) {
                      return DropdownMenuItem(
                        value: value,
                        child: Text(value),
                      );
                    },
                  ).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedValue = value;
                    });
                  }),
            ),
          ),
              Container(
                height: 400,
                child: _selectedValue == '경동대행'? Busscanlist() : Busscanlistpm(),

              )
          ]
        ),
      );
    }
  }
/*
  final _busto = ['경동대행', '도봉산행'];
  var _selectedValue = '경동대행';
  //var col =  Firestore.instance.collection('Bus').document('busAM').collection('nine').document(doc.documentID);

  int _count = 0;
  int max = 40;

  List<String> buslistAm = ['nine', 'ten', 'eleven'];
  List<String> buslistPm = ['five', 'six', 'seven'];
  List<String> titlelist = ['_one', '_two', '_thr', '_four'];

  String str;
  String busTime;
  String busText;



  Widget pageViewBus( String selectedValue){
    List<String> busList;

    if(_selectedValue == '경동대행'){
      busTime = 'busAM';
      busList = buslistAm;
    } else {
      busTime = 'busPM';
      busList = buslistPm;
    }

    for(int i = 0; busList.length < 0 ; i++){

      if(busList[i] == 'nine'){
        busText = " 경동대, 9시 20분 도착";
      } else if(busList[i] == 'ten'){
        busText = " 경동대, 10시 20분 도착";
      } else if(busList[i] == 'eleven'){
        busText = " 경동대, 11시 20분 도착";
      } else if(busList[i] == 'five'){
        busText = " 도봉산역, 5시 도착";
      } else if(busList[i] == 'five'){
        busText = " 도봉산역, 6시 도착";
      } else {
        busText = " 도봉산역, 7시 도착";
      }

      Container(
        child: Column(
            children: <Widget>[
              Container(
                margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                child: Row(
                    children: <Widget>[
                      Icon(Icons.directions_bus,
                        color: Colors.blueAccent,),
                      Text(busText,
                        style: TextStyle(
                            fontSize: 18,
                            color: Colors.black,
                            fontWeight: FontWeight.bold
                        ),
                      ),
                    ]
                ),
              ),
              StreamBuilder<QuerySnapshot>(
                  stream: Firestore.instance.collection('Bus').document(busTime)
                      .collection(busList[i]).orderBy('title', descending: false).snapshots(),
                  builder: (context, snapshot) {
                    if(!snapshot.hasData){
                      return CircularProgressIndicator();
                    }
                    final documents = snapshot.data.documents;
                    return Expanded(
                      child: ListView(
                        children: documents
                            .map((doc) => _buildBusstateWidget(doc, busTime,
                            busList[i], titlelist)).toList(),
                      ),
                    );
                  }
              ),


            ]


        ),
      );
    }

  }

  Widget _buildBusstateWidget(DocumentSnapshot doc, String busTime,
      String busList, List<String> titleList) {
    final bus = Bus.all(doc['title'], doc['count'], doc['state']);



    return ListTile(
      onTap: () {
        setState(() {
          for(int i = 0 ; i < titleList.length ; i++){
            stream:
            Firestore.instance.collection('Bus').document(busTime)
                .collection(busList).document({busList+titleList[i]}.toString())
                .updateData({
              'count': doc['count'] + 1
              /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
            });
          }

        });
      } /*_toggleTodo(bus)*/,
      title: Text(bus.title),

      subtitle: Row(
        children: <Widget>[
          Expanded(child: Text('${bus.count}/40')),
          /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
        ],
      ),
      trailing: RaisedButton(
        child: Text('스캔'),
        onPressed: () {
          setState(() {

          });
        },
      ),
    );
  }


  Widget _buildBusstate2Widget(DocumentSnapshot doc) {
    final bus = Bus.all(doc['title'], doc['count'], doc['state']);



    return ListTile(
      onTap: () {
        setState(() {
            stream:
            Firestore.instance.collection('Bus').document(busTime)
                .collection('nine').document(doc.documentID)
                .updateData({
              'count': doc['count'] + 1
              /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
            });
          }
        );
      } /*_toggleTodo(bus)*/,
      title: Text(bus.title),

      subtitle: Row(
        children: <Widget>[
          Expanded(child: Text('${bus.count}/40')),
          /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
        ],
      ),
      trailing: RaisedButton(
        child: Text('스캔'),
        onPressed: () {
          setState(() {

          });
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                padding: EdgeInsets.all(20.0),
                child: DropdownButton(
                    value: _selectedValue,
                    items: _busto.map(
                        (value) {
                          return DropdownMenuItem(
                            value: value,
                            child: Text(value),
                          );
                        },
                    ).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedValue = value;
                      });
                    }),
              ),
            ),
            Container(
              height: 400,
              child: PageView(
                children: [
                  Container(
                    child: Column(
                        children: <Widget>[
                          Container(
                            margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                            child: Row(
                                children: <Widget>[
                                  Icon(Icons.directions_bus,
                                    color: Colors.blueAccent,),
                                  Text(busText,
                                    style: TextStyle(
                                        fontSize: 18,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold
                                    ),
                                  ),
                                ]
                            ),
                          ),
                          StreamBuilder<QuerySnapshot>(
                              stream: Firestore.instance.collection('Bus').document('busAM')
                                  .collection('nine').orderBy('title', descending: false).snapshots(),
                              builder: (context, snapshot) {
                                if(!snapshot.hasData){
                                  return CircularProgressIndicator();
                                }
                                final documents = snapshot.data.documents;
                                return Expanded(
                                  child: ListView(
                                    children: documents
                                        .map((doc) => _buildBusstate2Widget(doc)).toList(),
                                  ),
                                );
                              }
                          ),


                        ]


                    ),
                  ),

                ],
              ),
            ),
          ],
        )
    );
  }
}*/

