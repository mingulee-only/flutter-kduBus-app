class Bus{
  String title;
  int count;
  String state;

  Bus();
  Bus.all(this.title, this.count, this.state);
}