import 'package:flutter/material.dart';
import 'page1.dart';
import 'page2.dart';
import 'page3.dart';
//import 'buslist_am.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MainManager extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'kduApp',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
      ),
      home: ManagerHome(),
    );
  }
}


class ManagerHome extends StatefulWidget {
  @override
  _ManagerHomeState createState() => _ManagerHomeState();
}

class _ManagerHomeState extends State<ManagerHome> {
  var _index = 0;
  var _pages = [
    Page1(),
    Page2(),
    Page3(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.white,
          title: Text(
            '경동대학교 통학 어플',
            style: TextStyle(color: Colors.black),
          ), //맨 위 상단 페이지 이름, 색상 변경
          centerTitle: true,
          actions: <Widget>[
            IconButton(
              icon: Icon(
                Icons.dehaze,
                color: Colors.black,
              ),
              onPressed: () {},
            )
          ]),
      body: _pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blueAccent,
        unselectedItemColor: Colors.white60,
        fixedColor: Colors.white,
        onTap: (index) {
          setState(() {
            _index = index;
          });
        },
        currentIndex: _index,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            label: '버스관리',
            icon: Image.asset('icon/bus_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill, color: Colors.white38,),
            activeIcon: Image.asset('icon/bus_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill,),
          ),
          BottomNavigationBarItem(
            label: 'QR스캐너',
            icon: Image.asset('icon/qrscan_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill, color: Colors.white38,),
            activeIcon: Image.asset('icon/qrscan_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill,),
          ),
          BottomNavigationBarItem(
            label: '설정',
            icon: Image.asset('icon/setting_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill, color: Colors.white38,),
            activeIcon: Image.asset('icon/setting_white_36_1x.png',
              width: 30, height: 30, fit: BoxFit.fill,),

          )
        ],
      ),
    );
  }
}
