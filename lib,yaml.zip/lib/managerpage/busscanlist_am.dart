import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../scannerpage/nine/scanAM_nineone.dart';
import '../scannerpage/nine/scanAM_ninetwo.dart';
import '../scannerpage/nine/scanAM_ninethr.dart';
import '../scannerpage/nine/scanAM_ninefour.dart';
import '../scannerpage/ten/scanAM_tenone.dart';
import '../scannerpage/ten/scanAM_tentwo.dart';
import '../scannerpage/ten/scanAM_tenthr.dart';
import '../scannerpage/ten/scanAM_tenfour.dart';
import '../scannerpage/eleven/scanAM_elevenone.dart';
import '../scannerpage/eleven/scanAM_eleventwo.dart';


import 'models/bus_model.dart';

class Busscanlist extends StatefulWidget {
  @override
  _BusscanlistState createState() => _BusscanlistState();
}


class _BusscanlistState extends State<Busscanlist> {
  int _count = 0;
  int max = 40;
  List<String> buslistAm = ['nine', 'ten', 'eleven',];
  List<String> buslistPm = ['five', 'six', 'seven'];
  List<String> titlelist = ['_one', '_two', '_thr', '_four'];


  Widget _buildBusstateWidget(DocumentSnapshot doc, String busTime, ) {
    final bus = Bus.all(doc['title'], doc['count'], doc['state']);
    if(busTime == 'nine'){
      if(doc.documentID == 'nine_one'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_nineone()));
              });
            },
          ),
        );
      } else if(doc.documentID == 'nine_two'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_ninetwo()));
              });
            },
          ),
        );
      } else if(doc.documentID == 'nine_thr'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_ninethr()));
              });
            },
          ),
        );
      } else{
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_ninefour()));
              });
            },
          ),
        );
      }
    } else if (busTime == 'ten'){ ///10시 반
      if(doc.documentID == 'ten_one'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_tenone()));
              });
            },
          ),
        );
      } else if(doc.documentID == 'ten_two'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_tentwo()));
              });
            },
          ),
        );
      } else if(doc.documentID == 'ten_thr'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_tenthr()));
              });
            },
          ),
        );
      } else{
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_tenfour()));
              });
            },
          ),
        );
      }
    } else {  ///11시반
      if(doc.documentID == 'eleven_one'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_elevenone()));
              });
            },
          ),
        );
      } else{
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busAM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_eleventwo()));
              });
            },
          ),
        );
      }
    }

  }


  @override
  Widget build(BuildContext context) {
    final bus = Bus();

    return Scaffold(
      body: PageView(
        children : <Widget>[
          Container(
            child: Column(
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                    child: Row(
                        children: <Widget>[
                          Icon(Icons.directions_bus,
                            color: Colors.blueAccent,),
                          Text(" 경동대, 9시 20분 도착",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.black,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ]
                    ),
                  ),
                  StreamBuilder<QuerySnapshot>(
                      stream: Firestore.instance.collection('Bus').document('busAM')
                          .collection('nine').orderBy('title', descending: false).snapshots(),
                      builder: (context, snapshot) {
                        if(!snapshot.hasData){
                          return CircularProgressIndicator();
                        }
                        final documents = snapshot.data.documents;
                        return Expanded(
                          child: ListView(
                            children: documents
                                .map((doc) => _buildBusstateWidget(doc, 'nine')).toList(),
                          ),
                        );
                      }
                  ),

                ]


            ),
          ),
          Container(
            child: Column(
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                    child: Row(
                        children: <Widget>[
                          Icon(Icons.directions_bus,
                            color: Colors.blueAccent,),
                          Text(" 경동대, 10시 20분 도착",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.black,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ]
                    ),
                  ),
                  StreamBuilder<QuerySnapshot>(
                      stream: Firestore.instance.collection('Bus').document('busAM')
                          .collection('ten').orderBy('title', descending: false).snapshots(),
                      builder: (context, snapshot) {
                        if(!snapshot.hasData){
                          return CircularProgressIndicator();
                        }
                        final documents = snapshot.data.documents;
                        return Expanded(
                          child: ListView(
                            children: documents
                                .map((doc) => _buildBusstateWidget(doc, 'ten')).toList(),
                          ),
                        );
                      }
                  ),

                ]


            ),
          ),
          Container(
            child: Column(
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                    child: Row(
                        children: <Widget>[
                          Icon(Icons.directions_bus,
                            color: Colors.blueAccent,),
                          Text(" 경동대, 11시 20분 도착",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.black,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ]
                    ),
                  ),
                  StreamBuilder<QuerySnapshot>(
                      stream: Firestore.instance.collection('Bus').document('busAM')
                          .collection('eleven').orderBy('title', descending: false).snapshots(),
                      builder: (context, snapshot) {
                        if(!snapshot.hasData){
                          return CircularProgressIndicator();
                        }
                        final documents = snapshot.data.documents;
                        return Expanded(
                          child: ListView(
                            children: documents
                                .map((doc) => _buildBusstateWidget(doc, 'eleven')).toList(),
                          ),
                        );
                      }
                  ),

                ]


            ),
          ),
        ],

      ),


    );
  }
}
