import 'package:flutter/material.dart';
import 'package:flutter_loginemailex1/managerpage/buslist_am.dart';
import 'buslist_am.dart';
import 'buslist_pm.dart';

class Page1 extends StatefulWidget{
  _Page1State createState() => _Page1State();

}

class _Page1State extends State<Page1> {
  @override
  Widget build(BuildContext context) {
    return _buildTop(context);
    //return _buildMiddle();
    //return _buildBottom();

  }
}

Widget _buildTop(BuildContext context) {
  return ListView(
    scrollDirection: Axis.vertical,
    children: [
      ListTile(
        leading: Text('등교 (도봉산역 → 경동대)',
          style: TextStyle(fontSize: 18),
        ),
        trailing: Icon(Icons.chevron_right),
        onTap: (){
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => Buslistam()),
          );
        },
      ),
      ListTile(
        leading: Text('하교 (경동대 → 도봉산역)',
          style: TextStyle(fontSize: 18),),
        trailing: Icon(Icons.chevron_right),
        onTap: (){
          Navigator.push(
            context, MaterialPageRoute(builder: (context) => Buslistpm()),
          );
        },
      )
    ],
  );
}

  Widget _buildMiddle() {
    return Text('Middle');
  }

  Widget _buildBottom() {
    return Text('Bottom');
  }

