import 'package:flutter/material.dart';
import 'package:flutter_loginemailex1/flutter_firebase/choiceIdenti.dart';
import 'package:flutter_loginemailex1/flutter_firebase/editedinMan.dart';
import 'package:flutter_loginemailex1/flutter_firebase/firebase_provider.dart';
import 'package:flutter_loginemailex1/flutter_firebase/mail/signin_page.dart';
import 'package:flutter_loginemailex1/flutter_firebase/signedinMan.dart';
import 'package:flutter_loginemailex1/flutter_firebase/signedinUser.dart';
import 'package:flutter_loginemailex1/flutter_firebase/user_provider.dart';
import 'package:flutter_loginemailex1/questionmain_man.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_loginemailex1/flutter_firebase/user_provider.dart';

class Page3 extends StatefulWidget {
  @override
  _Page3State createState() => _Page3State();
}

class _Page3State extends State<Page3> {
  FirebaseProvider fp;
  UserProvider up;
  String namepage = 'no';


  String id = '';
  String name = '';
  String number = '';
  String roll = '';

  void settingtestUser() async {
    final QuerySnapshot result = await Firestore.instance
        .collection('User')
        .where('userId', isEqualTo: fp.getUser().uid)
        .getDocuments();
    final List<DocumentSnapshot> documents = result.documents;
    id = documents[0].data['id'] ?? '';
    name = documents[0].data['name'] ?? '';
    roll = documents[0].data['roll'] ?? '';
  }


  Future<String> _buildStudentNumberWidget() async {
    final QuerySnapshot result = await Firestore.instance
        .collection('User')
        .where('userId', isEqualTo: fp.getUser().uid)
        .getDocuments();
    final List<DocumentSnapshot> documents = result.documents;
    if(documents[0].data['name'] != null){
      namepage = 'yes';
    } else {
      namepage = 'no';
    }
    return namepage;
  }

  @override
  Widget build(BuildContext context) {
    fp = Provider.of<FirebaseProvider>(context);

    _buildStudentNumberWidget();

    setState(() {
      settingtestUser();
    });

    if(namepage == 'yes'){
      return Column(
        children: <Widget>[
          _buildTop(),
          _buildMiddle(),
          _buildBottom(),
        ],
      );
    } else {
      return Column(
        children: <Widget>[
          _buildTopNo(),
          _buildMiddleNo(),
          _buildBottom(),
        ],
      );
    }
  }


  Widget _buildTopNo() {
    return Container(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children:<Widget> [
          Container(
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.all(20.0),
            child: CircleAvatar(
              backgroundColor: Colors.indigo,
              child: Icon(Icons.person, color: Colors.white),
              radius: 30,
            ),
          ),

          Expanded(
            child: Container(
              alignment: Alignment.centerLeft,
              child: Row(
                children: [
                  Text('이름이 없습니다.'),
                ],
              ),
            ),
          ),

        ],
      ),
    );
  }


  Widget _buildMiddleNo() {
    return Container(
      margin: const EdgeInsets.only(left: 20, right: 20, bottom: 10),
      child: Column(

        children: [
          SizedBox(
            height:20,
          ),
          Text('어플을 이용하시려면 이름 등록이 필요합니다.'),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Text('정보 등록'),
                IconButton(
                  icon: Icon(Icons.navigate_next),
                  onPressed: (){
                    setState(() {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => SignedInMan()));
                    });

                  },
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTop() {
    return Container(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children:<Widget> [
          Container(
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.all(20.0),
            child: CircleAvatar(
              backgroundColor: Colors.indigo,
              child: Icon(Icons.person, color: Colors.white),
              radius: 30,
            ),
          ),

          Expanded(
            child: Container(
              alignment: Alignment.centerLeft,
              child: Row(
                children: [
                  Text('$name 관리자'),
                ],
              ),
            ),
          ),

        ],
      ),
    );
  }


  Widget _buildMiddle() {
    return Container(
      margin: const EdgeInsets.only(left: 20, right: 20, bottom: 10),
      child: Column(

        children: [
          SizedBox(
            height:20,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Text('내 정보 관리'),
                IconButton(
                  icon: Icon(Icons.navigate_next),
                  onPressed: (){
                    setState(() {
                      Navigator.push(context, MaterialPageRoute(builder:(context) => EditedInMan()));
                    });

                  },
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Text('학생과 소통하기'),
                IconButton(
                  icon: Icon(Icons.navigate_next),
                  onPressed: (){
                    setState(() {
                      Navigator.push(context, MaterialPageRoute(builder:(context) => ToStuListPage()));
                    });
                  },
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottom() {

    return Align(
      alignment: Alignment.bottomLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: RaisedButton(
          color: Colors.blue[300],
          child: Text(
            "로그아웃",
            style: TextStyle(color: Colors.white),
          ),
          onPressed: () {
            setState(() {
              fp.signOut();
            });
          },
        ),
      ),
    );
  }
}
