import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_loginemailex1/scannerpage/eleven/scanAM_elevenone.dart';
import 'package:flutter_loginemailex1/scannerpage/eleven/scanAM_eleventwo.dart';
import 'package:flutter_loginemailex1/scannerpage/five/scanPM_fiveone.dart';
import 'package:flutter_loginemailex1/scannerpage/five/scanPM_fivetwo.dart';
import 'package:flutter_loginemailex1/scannerpage/nine/scanAM_ninefour.dart';
import 'package:flutter_loginemailex1/scannerpage/nine/scanAM_nineone.dart';
import 'package:flutter_loginemailex1/scannerpage/nine/scanAM_ninethr.dart';
import 'package:flutter_loginemailex1/scannerpage/nine/scanAM_ninetwo.dart';
import 'package:flutter_loginemailex1/scannerpage/seven/scanPM_sevenone.dart';
import 'package:flutter_loginemailex1/scannerpage/seven/scanPM_seventwo.dart';
import 'package:flutter_loginemailex1/scannerpage/six/scanPM_sixone.dart';
import 'package:flutter_loginemailex1/scannerpage/six/scanPM_sixtwo.dart';
import 'package:flutter_loginemailex1/scannerpage/ten/scanAM_tenfour.dart';
import 'package:flutter_loginemailex1/scannerpage/ten/scanAM_tenone.dart';
import 'package:flutter_loginemailex1/scannerpage/ten/scanAM_tenthr.dart';
import 'package:flutter_loginemailex1/scannerpage/ten/scanAM_tentwo.dart';

import 'models/bus_model.dart';

class Busscanlistpm extends StatefulWidget {
  @override
  _BusscanlistpmState createState() => _BusscanlistpmState();
}


class _BusscanlistpmState extends State<Busscanlistpm> {
  int _count = 0;
  int max = 40;
  List<String> buslistAm = ['nine', 'ten', 'eleven',];
  List<String> buslistPm = ['five', 'six', 'seven'];
  List<String> titlelist = ['_one', '_two', '_thr', '_four'];


  Widget _buildBusstateWidget(DocumentSnapshot doc, String busTime, ) {
    final bus = Bus.all(doc['title'], doc['count'], doc['state']);
    if(busTime == 'five'){
      if(doc.documentID == 'five_one'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_fiveone()));
              });
            },
          ),
        );
      } else{
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_fivetwo()));
              });
            },
          ),
        );
      }
    } else if (busTime == 'six'){ ///6시 반
      if(doc.documentID == 'six_one'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_sixone()));
              });
            },
          ),
        );
      } else{
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_sixtwo()));
              });
            },
          ),
        );
      }
    } else {  ///7시
      if(doc.documentID == 'seven_one'){
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_sevenone()));
              });
            },
          ),
        );
      } else{
        return ListTile(
          onTap: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] < 40? doc['count'] + 1 : 40
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          } /*_toggleTodo(bus)*/,
          onLongPress: () {
            setState(() {
              stream:
              Firestore.instance.collection('Bus').document('busPM')
                  .collection(busTime).document(doc.documentID).updateData({
                'count': doc['count'] > 0 ? doc['count'] - 1 : 0
                /*doc['count'] < max ? {'count' : doc['count']+1} : 'count' : 40*/,
              });
            });
          },
          title: Text(bus.title),

          subtitle: Row(
            children: <Widget>[
              Expanded(child: Text('${bus.count}/40')),
              /*Expanded(child:
          Text(bus.state,
            style: TextStyle(color: Colors.redAccent,
              fontWeight: FontWeight.bold,
            ),
          )),*/
            ],
          ),
          trailing: RaisedButton(
            child: Text('스캔'),
            onPressed: () {
              setState(() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => QRViewExample_seventwo()));
              });
            },
          ),
        );
      }
    }

  }


  @override
  Widget build(BuildContext context) {
    final bus = Bus();

    return Scaffold(
      body: PageView(
        children : <Widget>[
          Container(
            child: Column(
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                    child: Row(
                        children: <Widget>[
                          Icon(Icons.directions_bus,
                            color: Colors.blueAccent,),
                          Text(" 도봉산역, 5시 도착",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.black,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ]
                    ),
                  ),
                  StreamBuilder<QuerySnapshot>(
                      stream: Firestore.instance.collection('Bus').document('busPM')
                          .collection('five').orderBy('title', descending: false).snapshots(),
                      builder: (context, snapshot) {
                        if(!snapshot.hasData){
                          return CircularProgressIndicator();
                        }
                        final documents = snapshot.data.documents;
                        return Expanded(
                          child: ListView(
                            children: documents
                                .map((doc) => _buildBusstateWidget(doc, 'five')).toList(),
                          ),
                        );
                      }
                  ),

                ]


            ),
          ),
          Container(
            child: Column(
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                    child: Row(
                        children: <Widget>[
                          Icon(Icons.directions_bus,
                            color: Colors.blueAccent,),
                          Text(" 도봉산역, 6시 도착",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.black,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ]
                    ),
                  ),
                  StreamBuilder<QuerySnapshot>(
                      stream: Firestore.instance.collection('Bus').document('busPM')
                          .collection('six').orderBy('title', descending: false).snapshots(),
                      builder: (context, snapshot) {
                        if(!snapshot.hasData){
                          return CircularProgressIndicator();
                        }
                        final documents = snapshot.data.documents;
                        return Expanded(
                          child: ListView(
                            children: documents
                                .map((doc) => _buildBusstateWidget(doc, 'six')).toList(),
                          ),
                        );
                      }
                  ),

                ]


            ),
          ),
          Container(
            child: Column(
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
                    child: Row(
                        children: <Widget>[
                          Icon(Icons.directions_bus,
                            color: Colors.blueAccent,),
                          Text(" 도봉산역, 7시 도착",
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.black,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ]
                    ),
                  ),
                  StreamBuilder<QuerySnapshot>(
                      stream: Firestore.instance.collection('Bus').document('busPM')
                          .collection('seven').orderBy('title', descending: false).snapshots(),
                      builder: (context, snapshot) {
                        if(!snapshot.hasData){
                          return CircularProgressIndicator();
                        }
                        final documents = snapshot.data.documents;
                        return Expanded(
                          child: ListView(
                            children: documents
                                .map((doc) => _buildBusstateWidget(doc, 'seven')).toList(),
                          ),
                        );
                      }
                  ),

                ]


            ),
          ),
        ],

      ),


    );
  }
}
