import 'package:barcode_scan/barcode_scan.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_loginemailex1/flutter_firebase/firebase_provider.dart';
import 'package:provider/provider.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:url_launcher/url_launcher.dart';


const flashOn = 'FLASH ON';
const flashOff = 'FLASH OFF';
const frontCamera = 'FRONT CAMERA';
const backCamera = 'BACK CAMERA';

class QRViewExample_nineone extends StatefulWidget {


  QRViewExample_nineone({
    Key key
  }) : super(key: key);


  @override
  State<StatefulWidget> createState() => _QRViewExample_nineoneState();
}

class _QRViewExample_nineoneState extends State<QRViewExample_nineone> {
  var qrText = '';
  var flashState = flashOn;
  var cameraState = frontCamera;
  QRViewController controller;
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  var count = 0;
  FirebaseProvider fp;
  DocumentSnapshot doc;

  String busTo = 'busAM';
  String busTime = 'nine';
  String busDoc = 'nine_one';

  _QRViewExample_nineoneState();


  @override
  initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    fp = Provider.of<FirebaseProvider>(context);

    return Scaffold(
      body: Column(
        children: <Widget>[
          Expanded(
            flex: 4,
            child: QRView(
              key: qrKey,
              onQRViewCreated: _onQRViewCreated,
              overlay: QrScannerOverlayShape(
                borderColor: Colors.amber,
                borderRadius: 10,
                borderLength: 30,
                borderWidth: 10,
                cutOutSize: 300,
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: FittedBox(
              fit: BoxFit.contain,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Text('This is the result of scan: $qrText'),
                  Row(  //버튼 윗줄
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Container(  //flash on
                        margin: EdgeInsets.all(8),
                        child: RaisedButton(
                          onPressed: () {
                            if (controller != null) {
                              controller.toggleFlash();
                              if (_isFlashOn(flashState)) {
                                setState(() {
                                  flashState = flashOff;
                                });
                              } else {
                                setState(() {
                                  flashState = flashOn;
                                });
                              }
                            }
                          },
                          child:  //flashState=flash on
                          Text(flashState, style: TextStyle(fontSize: 20)),
                        ),
                      ),
                      Container(  //camera flip
                        margin: EdgeInsets.all(8),
                        child: RaisedButton(
                          color: Colors.lightBlue,
                          onPressed: () {
                            if (controller != null) {
                              controller.flipCamera();  //기본값 = back Camera / 글씨는 front
                              if (_isBackCamera(cameraState)) {
                                setState(() {
                                  cameraState = frontCamera;
                                });
                              } else {
                                setState(() {
                                  cameraState = backCamera;
                                });
                              }
                            }
                          },
                          child:  //camera 상태는 버튼 누르는 대로 바뀌기 때문에 변수 사용
                          Text(cameraState, style: TextStyle(fontSize: 20, color: Colors.white)),
                        ),
                      )
                    ],
                  ),
                  Row(  //버튼 아랫줄
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Container(  //카메라 잠시 멈추는 거
                        margin: EdgeInsets.all(8),
                        child: RaisedButton(
                          onPressed: () {
                            controller?.pauseCamera();
                          },
                          child: Text('정지', style: TextStyle(fontSize: 20)),
                        ),
                      ),
                      Container(  //멈춘 거 푸는 거
                        margin: EdgeInsets.all(8),
                        child: RaisedButton(
                          onPressed: () {
                            controller?.resumeCamera();
                          },
                          child: Text('재개', style: TextStyle(fontSize: 20)),
                        ),
                      ),
                      Container(
                          margin : EdgeInsets.all(8),
                          child: RaisedButton(
                            color: Colors.amberAccent,
                            onPressed: (){
                              Navigator.pop(context, addCount());
                            },
                            child: Text('닫기',
                                style: TextStyle(
                                  fontSize: 20, color:Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                            ),
                          )
                      )
                    ],
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }


  LaunchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  bool _isFlashOn(String current) {
    return flashOn == current;
  }

  bool _isBackCamera(String current) {
    return backCamera == current;
  }

  void _onQRViewCreated (QRViewController controller) {

    this.controller = controller;
    controller.scannedDataStream.listen((scanData) {
      setState(() {
        this.qrText = scanData as String;
      });
      addQr(busTo, busTime, busDoc);
    });

  }

  Future addQr(String busTo, String busTime, String busDoc) async {


    final QuerySnapshot result = await Firestore.instance
        .collection('Bus').document(busTo).collection(busTime)
        .document(busDoc).collection('count')
        .where('numcount', isEqualTo: qrText)
        .getDocuments();


    final List<DocumentSnapshot> documents = result.documents;


    if(documents.length == 0){
      Firestore.instance
          .collection('Bus').document(busTo).collection(busTime)
          .document(busDoc)
          .collection('count').document(this.qrText).
      setData({'numcount' : this.qrText});

    } else {}

  }


  Future addCount() async {


    final QuerySnapshot result = await Firestore.instance
        .collection('Bus').document(busTo).collection(busTime)
        .document(busDoc).collection('count')
        .getDocuments();


    final List<DocumentSnapshot> documents = result.documents;


    if(documents.length == 0){


    } else {
      Firestore.instance
          .collection('Bus').document(busTo).collection(busTime)
          .document(busDoc).
      updateData({'count' : documents.length.toInt()});
    }
  }


  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
}
