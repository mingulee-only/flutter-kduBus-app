import 'package:flutter/material.dart';
import 'nine/scanAM_nineone.dart';

void scannerMain() {
  runApp(MyAppTest());
}

class MyAppTest extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'kduScanTest',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
      ),
        debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}


class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
          backgroundColor: Colors.white,
          title: Text(
            '스캐너 테스트',
            style: TextStyle(color: Colors.black),
          ), //맨 위 상단 페이지 이름, 색상 변경
          centerTitle: true,
          ),
          body: Center(
            child: Column(
                children: [
                  RaisedButton(
                    child: Text('스캔'),
                    onPressed: (){
                      Navigator.push(context,
                        MaterialPageRoute(builder: (context) => QRViewExample_nineone())
                      );
                    },
                  ),
                  RaisedButton(
                    child: Text('결과확인'),
                    onPressed: (){},
                  ),
              ],
            ),
          ),
        );

  }
}
